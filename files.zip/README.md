# 💼 PayCheck - PWA SaaS

**Comprendre sa fiche de paie et son contrat de travail avec un chatbot IA expert.**

> Une application web progressive (PWA) installable sur ordinateur, iPhone, iPad et Android sans passer par les app stores.

---

## 🚀 Démarrage rapide

### Option 1: Déployer sur Vercel (Recommandé - Gratuit)

1. **Créez un compte sur Vercel**
   - Allez sur https://vercel.com et inscrivez-vous

2. **Créez un dossier GitHub (optionnel mais recommandé)**
   ```bash
   # Créez un repo vide sur GitHub
   # Puis clonez-le et ajoutez les fichiers
   git clone https://github.com/VOTRE_USERNAME/paycheck.git
   cd paycheck
   ```

3. **Ajoutez les fichiers**
   ```
   paycheck/
   ├── index.html      (fichier principal)
   ├── sw.js           (service worker)
   ├── manifest.json   (configuration PWA)
   └── README.md       (ce fichier)
   ```

4. **Déployez sur Vercel**
   - Allez sur https://vercel.com/new
   - Importez votre repo GitHub
   - Cliquez "Deploy"
   - C'est tout! 🎉

### Option 2: Déployer sur Netlify

1. **Allez sur https://netlify.com**
2. **Drag & drop votre dossier** avec les fichiers
3. **Voilà!** Votre app est en ligne

### Option 3: Hébergement local (développement)

```bash
# Installez un serveur HTTP simple
npm install -g http-server

# Démarrez le serveur dans votre dossier
http-server .

# Ouvrez http://localhost:8080
```

---

## 🔑 Obtenir votre clé API Anthropic

L'app utilise Claude (l'IA la plus puissante) pour analyser vos documents.

1. **Allez sur https://console.anthropic.com**
2. **Créez un compte** (email + mot de passe)
3. **Allez sur "API Keys"** dans le menu
4. **Créez une nouvelle clé** (cliquez sur "Create Key")
5. **Copiez la clé** (elle commence par `sk-ant-`)
6. **Collez-la dans l'app** dans la section "Configuration"

💡 **Note**: La clé API reste **privée dans votre navigateur** - aucun serveur ne la voit.

**Tarification**: Claude offre un crédit gratuit de $5 pour démarrer. Après, c'est ~$0.01 par question.

---

## 📱 Installer sur votre téléphone

### iPhone / iPad
1. Ouvrez l'app dans Safari
2. Tapez le bouton **Partager**
3. Sélectionnez **"Sur l'écran d'accueil"**
4. Confirmez - l'app apparaît sur votre home screen! 📱

### Android
1. Ouvrez l'app dans Chrome
2. Tapez le menu **(3 points)**
3. Sélectionnez **"Installer l'app"**
4. Confirmez - l'app s'installe! 🤖

### Windows / Mac / Linux
1. Ouvrez l'app dans Chrome ou Edge
2. Cliquez sur le **bouton "Installer"** en haut à droite
3. Confirmez - l'app s'ajoute à vos applications! 💻

---

## 🎯 Comment utiliser

### 1️⃣ Configuration initiale
- Entrez votre clé API Anthropic (une seule fois)

### 2️⃣ Uploader vos documents
- **Fiches de paie**: Glissez-déposez votre PDF dans la section "Fiches de paie"
- **Contrats**: Glissez-déposez votre PDF dans la section "Contrats de travail"

### 3️⃣ Poser des questions
Exemples de questions:
- "Qu'est-ce qu'est la part patronale de cotisation?"
- "Que signifie IJSS sur ma fiche de paie?"
- "Quels sont mes droits de congé selon mon contrat?"
- "Comment est calculé mon net imposable?"
- "Y a-t-il une erreur sur ma fiche de paie?"

Le chatbot IA analysera vos documents et vous expliquera clairement.

---

## 🔒 Sécurité & Confidentialité

✅ **Vos documents restent privés**
- Les PDFs sont lus **uniquement dans votre navigateur**
- Aucun serveur n'a accès à vos fichiers

✅ **Votre clé API est protégée**
- Elle reste **stockée localement** dans votre navigateur
- Jamais sauvegardée ou transmise ailleurs

✅ **Pas de base de données centrale**
- Vos messages et documents sont sauvegardés **localement** sur votre appareil
- Vous gardez le contrôle total

---

## 🛠️ Architecture technique

### Stack
- **Frontend**: HTML5 + JavaScript vanilla (PWA)
- **IA**: API Anthropic (Claude)
- **PDF**: PDF.js (lecteur PDF intégré)
- **Storage**: LocalStorage (données locales)
- **Offline**: Service Worker + Cache API

### Fichiers
```
- index.html       → Application principale (tout le code)
- sw.js           → Service Worker (cache, offline)
- manifest.json   → Configuration PWA
```

### Comment ça marche
1. Vous uploadez un PDF → JavaScript l'extrait en texte
2. Vous posez une question → Envoyée à Claude via API
3. Claude analyse votre question + le texte extrait
4. La réponse s'affiche dans le chatbot

---

## 💡 Astuces

### Pour les développeurs
- L'app est **une seule page HTML** - facile à modifier
- Tous les styles sont **en CSS inline**
- Tout le code **en JavaScript vanilla** - pas de build needed

### Pour améliorer l'app
```javascript
// Vous pouvez modifier le systeme prompt pour Claude
const systemPrompt = `Tu es un expert en droit du travail...`

// Ou ajouter de nouvelles fonctionnalités
// L'architecture est simple et extensible
```

### Offline
- L'app **fonctionne hors ligne**
- Les PDFs sont stockés localement
- Les messages aussi (jusqu'à la prochaine connexion)

---

## 📊 Cas d'usage

Cette app est parfaite pour:
- ✅ Salariés cherchant à comprendre leur paie
- ✅ Jeunes découvrant leur premier emploi
- ✅ Expatriés en France découvrant le système français
- ✅ Professionnels du RH expliquant les fiches
- ✅ Étudiants en droit du travail
- ✅ Consultants en ressources humaines

---

## 🚨 Troubleshooting

### "La clé API ne fonctionne pas"
→ Vérifiez que votre clé commence par `sk-ant-`
→ Vérifiez que votre compte Anthropic a des crédits

### "Impossible de lire le PDF"
→ Assurez-vous que c'est un **PDF texte** (pas une image scannée)
→ Essayez de convertir le PDF si c'est une image

### "L'app ne s'installe pas"
→ Utilisez **Chrome** (Android) ou **Safari** (iPhone)
→ Vérifiez que l'app est servie en **HTTPS** (Vercel/Netlify le font automatiquement)

### "Mes données ne sont pas sauvegardées"
→ Vérifiez que le **LocalStorage n'est pas désactivé**
→ Mode Privé/Incognito ne sauvegarde pas les données

---

## 📈 Prochaines étapes

Fonctionnalités futures possibles:
- 📊 Extraction automatique des données (salaire, cotisations, etc.)
- 📈 Historique et tendances des fiches de paie
- 🔄 Synchronisation cloud (optionnel)
- 🌍 Support multilingue (anglais, espagnol, etc.)
- 📧 Export des explications en PDF
- 🤝 Partage sécurisé avec un conseiller

---

## 📞 Support

**Problème?** Consultez:
1. Ce README (vous le lisez!)
2. La console du navigateur (F12 → Console) pour les erreurs
3. Vérifiez votre clé API Anthropic
4. Réessayez après rafraîchir la page

---

## 📄 Licence

Cette application est **gratuite et open source**.
Utilisez-la, modifiez-la, partagez-la librement! 🎉

---

## 🙏 Merci!

Créée pour aider les gens à **comprendre leur paie** et leurs **droits du travail**.

Bonne utilisation! 💼✨
