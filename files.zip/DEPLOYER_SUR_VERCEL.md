# 🚀 Déployer PayCheck sur Vercel

## ⏱️ Temps total: 5 minutes

---

## 📋 Prérequis

Vous avez besoin de:
- ✅ Une adresse email (Gmail, Outlook, etc.)
- ✅ Un compte GitHub (gratuit) - **RECOMMANDÉ** mais optionnel
- ✅ Les 4 fichiers (index.html, sw.js, manifest.json, README.md)

---

## 🎯 Méthode 1: Avec GitHub (Recommandée)

### Étape 1: Créer un compte GitHub

1. Allez sur https://github.com
2. Cliquez **"Sign up"** (en haut à droite)
3. Entrez votre email
4. Créez un mot de passe
5. Choisissez un nom d'utilisateur (ex: `monnom`)
6. Cliquez **"Create account"**
7. Vérifiez votre email (GitHub vous enverra un lien)

**Voilà, vous avez un compte GitHub!** ✅

---

### Étape 2: Créer un dépôt pour votre app

1. Allez sur https://github.com/new
2. Remplissez:
   - **Repository name**: `paycheck` (ou le nom que vous voulez)
   - **Description**: `PWA pour comprendre sa fiche de paie`
   - **Public**: Cochez cette case
   - **Add a README file**: PAS BESOIN (vous en avez déjà un)
3. Cliquez **"Create repository"**

**Vous avez créé votre repo!** ✅

---

### Étape 3: Uploader vos fichiers

**Vous avez 2 options:**

#### Option A: Via le site GitHub (facile)

1. Vous êtes sur la page de votre repo
2. Cliquez **"Add file"** → **"Upload files"**
3. Glissez-déposez vos 4 fichiers:
   - `index.html`
   - `sw.js`
   - `manifest.json`
   - `README.md`
4. Cliquez **"Commit changes"**

**Vos fichiers sont uploadés!** ✅

#### Option B: Via Git (pour développeurs)

```bash
git clone https://github.com/VOTRE_USERNAME/paycheck.git
cd paycheck

# Copiez vos 4 fichiers dans ce dossier

git add .
git commit -m "Initial commit - PayCheck PWA"
git push origin main
```

---

### Étape 4: Connecter Vercel à GitHub

1. Allez sur https://vercel.com
2. Cliquez **"Sign up"** (en haut à droite)
3. Choisissez **"Continue with GitHub"**
4. GitHub vous demande: "Vercel veut accéder à vos repos"
5. Cliquez **"Authorize Vercel"**
6. Vous êtes maintenant sur Vercel ✅

---

### Étape 5: Importer votre projet

1. Sur Vercel, cliquez **"Add New..."** → **"Project"**
2. Sous "Import Git Repository", trouvez `paycheck`
3. Cliquez dessus
4. Cliquez **"Import"**
5. Les paramètres par défaut sont bons
6. Cliquez **"Deploy"**

**⏳ Patientez 30-60 secondes...**

**Voilà! Votre app est en ligne!** 🎉

---

### Étape 6: Récupérer votre URL

Une fois le déploiement terminé, vous verrez:
- Une URL comme: `https://paycheck-abc123.vercel.app`
- Cliquez dessus pour tester votre app!

---

## 🎯 Méthode 2: Sans GitHub (Vercel CLI)

Si vous préférez ne pas utiliser GitHub:

### Étape 1: Installer Vercel CLI

```bash
# Via npm (vous avez Node.js?)
npm install -g vercel

# Ou téléchargez depuis https://vercel.com/download
```

### Étape 2: Créer un dossier

```bash
mkdir paycheck
cd paycheck

# Mettez vos 4 fichiers dedans
# index.html
# sw.js
# manifest.json
# README.md
```

### Étape 3: Déployer

```bash
vercel

# Répondez aux questions:
# - Set up and deploy "..." ? → yes
# - Which scope ? → personnelle compte
# - Link to existing project ? → no
# - Project name ? → paycheck
# - Directory ? → ./
# - Override settings ? → no

# Voilà! L'app est déployée!
```

---

## 🎯 Méthode 3: Simple (Drag & Drop sur Vercel)

1. Allez sur https://vercel.com
2. Créez un compte (email ou GitHub)
3. Cliquez **"New Project"**
4. **Drag & drop votre dossier** avec les 4 fichiers
5. Vercel déploie automatiquement! ✅

---

## ✅ Vérifier que ça marche

Une fois déployé, testez votre app:

1. **Ouvrez votre URL** (ex: https://paycheck-abc123.vercel.app)
2. Vous devez voir:
   - Header avec logo "💼 PayCheck"
   - Sections pour uploader fiches et contrats
   - Chatbot avec zone de texte
3. **Testez l'installation**:
   - Cliquez le bouton **"📱 Installer"** (en haut)
   - L'app s'ajoute à votre home screen!

---

## 🔑 Obtenir votre clé API Anthropic

Maintenant que l'app est en ligne, il faut configurer l'IA:

1. Allez sur https://console.anthropic.com
2. Créez un compte (email + mot de passe)
3. Allez sur **"API Keys"** (menu à gauche)
4. Cliquez **"Create Key"**
5. Copiez la clé (commence par `sk-ant-`)
6. **Dans votre app**, collez-la dans la section "Configuration"
7. Voilà! Le chatbot IA est prêt 🤖

**💡 Conseil**: Anthropic vous donne $5 de crédit gratuit pour tester!

---

## 📱 Installer sur votre téléphone

### iPhone/iPad
1. Ouvrez votre URL dans **Safari**
2. Tapez le bouton **Partager** (rectangle avec flèche)
3. Sélectionnez **"Sur l'écran d'accueil"**
4. Confirmez

### Android
1. Ouvrez votre URL dans **Chrome**
2. Tapez le menu **⋮ (3 points)**
3. Sélectionnez **"Installer l'app"**
4. Confirmez

### Windows/Mac
1. Ouvrez votre URL dans **Chrome ou Edge**
2. Cliquez le bouton d'installation (⬇️ + symbole PWA)
3. Confirmez

**Et voilà! L'app est installée!** 📱

---

## 🚨 Troubleshooting

### "Erreur au déploiement"
→ Vérifiez que les 4 fichiers sont dans le dossier
→ Vérifiez les noms: `index.html` (pas `pwa-saas.html`)

### "L'app ne s'installe pas"
→ Utilisez HTTPS (Vercel le fait automatiquement)
→ Utilisez Chrome (Android) ou Safari (iPhone)
→ Attendez 30 secondes après le chargement

### "Le chatbot ne répond pas"
→ Avez-vous entré votre clé API Anthropic?
→ La clé commence par `sk-ant-`?
→ Avez-vous du crédit sur votre compte Anthropic?

---

## 🎉 C'est fait!

Vous avez maintenant:
- ✅ Une app PWA en ligne
- ✅ Installable sur tous les appareils
- ✅ Un chatbot IA intégré
- ✅ 100% gratuit

**Prochaines étapes:**
1. Testez l'app en uploadant une vraie fiche de paie
2. Posez des questions au chatbot
3. Partagez l'URL avec vos amis/collègues

---

## 📞 Questions?

Consultez le **README.md** complet pour plus de détails!

Bon usage! 💼✨
